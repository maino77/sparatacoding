# Kakao Developers에서 발급받은 정보를 저장하는 공간 [공개되면 곤란한 공간ㅠ_ㅠ]

# REST API key = CLIENT_ID
CLIENT_ID = "ea736aef7ee00af000b4a37dbc48aa5d"
CLIENT_SECRET = "ZRu4vKklCpCp8Wy4AYcQIYgKvseO6JYi"
REDIRECT_URI = "http://localhost:5000/oauth"
